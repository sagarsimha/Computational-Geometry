latest changes: 10/11/2019

######### Linux ##########
- dependencies: glut/freeglut build-essential
- on ubuntu: sudo apt-get install freeglut3-dev build-essential

To compile just type:
make

To run the example for exercise 1:
./example input1.txt output1.txt

To run the example for exercise 2:
./example input2.txt output2.txt

######### Windows ##########
- Visual Studio 2010 or later
- for newer versions, upgrade gl_example_vs2010.vcxproj

Build the solution and start the example either from a command line prompt or pass input1.txt output1.txt (or any other valid input.txt and output.txt) as cmd-line arguments in Visual Studio.





